import ti_plotlib as plt

plt.cls()
plt.color(0, 0, 0)
plt.line(0, 0, 5, 5, "arrow")
plt.show_plot()
