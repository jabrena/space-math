import ti_plotlib as plt

plt.cls()
plt.window(-10, 10, -10, 10)
plt.axes("on")
plt.grid(1, 1, "dot")
plt.title("TITLE")
plt.pen("medium", "solid")
plt.color(28, 242, 221)
plt.pen("medium", "dash")
plt.line(-5, 5, 5, -5, "")
plt.color(224, 54, 243)
plt.line(-5, -5, 5, 5, "")
plt.show_plot()
