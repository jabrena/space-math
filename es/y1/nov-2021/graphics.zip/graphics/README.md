# Chapter 02

## Learning Goals

- Learn with the examples provided by TI some features included with the calculator.
- Deploy multiple programs 

## References

- https://education.ti.com/html/webhelp/EG_TI84PlusCE-T/ES/content/eg_pythonappprog/m_pygetstart/m_samprog.HTML#COLORLIN
